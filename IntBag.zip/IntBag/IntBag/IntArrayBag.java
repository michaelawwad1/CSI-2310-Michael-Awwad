/**
 * IntArrayBag.java provides an implementation of IntBag
 *
 * Created on January 27, 2004
 * Modified on July 14, 2016
 */
public class IntArrayBag implements IntBag {
  private int manyItems;
  private int[] data;

  public IntArrayBag() {
    manyItems = 0;
    data = new int[10];
  }

  public IntArrayBag(int initialCapacity) {
    if (initialCapacity < 0)
      throw new IllegalArgumentException("The initialCapacity is negative");
    data = new int[initialCapacity];
    manyItems = 0;
  }

  public void add(int element) {
    if (manyItems == data.length)
      ensureCapacity(manyItems * 2 + 1);
    data[manyItems] = element;
    manyItems++;
  }

  public void addAll(IntBag addend) {
    if (addend instanceof IntArrayBag) {
      IntArrayBag second = (IntArrayBag) addend;
      ensureCapacity(manyItems + second.manyItems);
      System.arraycopy(second.data, 0, data,
          manyItems, second.manyItems);
      manyItems += second.manyItems;
    } else
      throw new IllegalArgumentException("The input bag is not array-based!");
  }

  public IntArrayBag clone() {
    IntArrayBag answer;

    try {
      answer = (IntArrayBag) super.clone();
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException("This class does not implement Cloneable");
    }

    answer.data = (int[]) data.clone();

    return answer;
  }

  public int countOccurrences(int target) {
    int answer;
    int index;

    answer = 0;
    for (index = 0; index < manyItems; index++)
      if (target == data[index])
        answer++;
    return answer;
  }

  public boolean remove(int target) {
    int index; // The location of target in the data array.

    for (index = 0; (index < manyItems) &&
        (target != data[index]); index++)
      ;

    if (index == manyItems)
      return false;
    else {
      manyItems--;
      data[index] = data[manyItems];
      return true;
    }
  }

  public int size() {
    return manyItems;
  }

  public void trimToSize() {
    int trimmedArray[];

    if (data.length != manyItems) {
      trimmedArray = new int[manyItems];
      System.arraycopy(data, 0, trimmedArray,
          0, manyItems);
      data = trimmedArray;
    }
  }

  public IntBag union(IntBag b) {
    if (b instanceof IntArrayBag) {
      IntArrayBag snd = (IntArrayBag) b;
      IntArrayBag answer = new IntArrayBag(data.length + snd.data.length);
      System.arraycopy(data, 0, answer.data, 0, manyItems);
      System.arraycopy(snd.data, 0, answer.data, manyItems, snd.manyItems);
      answer.manyItems = manyItems + snd.manyItems;
      return answer;
    } else
      throw new IllegalArgumentException("Input bag is not array-based");
  }

  public String toString() {
    StringBuffer str = new StringBuffer();
    for (int k = 0; k < manyItems; k++)
      str.append(data[k]).append(" ");
    return new String(str);
  }

  /**
   * @pre None
   * @post Duplicate elements have been removed from this bag.
   *       Each element occurs in this bag exactly once.
   *       This bag contains an element if and only if the element
   *       occurred in the bag before.
   */
  public void removeDup() {
    int i, j;

    // For each element position
    for (i = 0; i < manyItems; i++) {
      // Check all positions after i for duplicates
      j = i + 1;
      while (j < manyItems) {
        // If we find a duplicate
        if (data[i] == data[j]) {
          // Remove it by replacing with last element
          manyItems--;
          data[j] = data[manyItems];
          // Don't increment j since we need to check
          // the element we just moved to position j
        } else {
          // No duplicate found, move to next position
          j++;
        }
      }
    }
  }

  private void ensureCapacity(int minimumCapacity) {
    int biggerArray[];

    if (data.length < minimumCapacity) {
      biggerArray = new int[minimumCapacity];
      System.arraycopy(data, 0, biggerArray, 0, manyItems);
      data = biggerArray;
    }
  }

}