/*
 * IntBag.java
 *
 * Created on January 27, 2004
 * Revised on January 30, 2008
 * Revised on July 14, 2016
 */

/**
 *
 * @author Lunjin Lu
 */
public interface IntBag extends Cloneable {

    /**
     * 
     * @pre NONE
     * @post element has been added into this bag.
     * 
     */

    public void add(int element);

    public void addAll(IntBag addend);

    public int countOccurrences(int target);

    public boolean remove(int target);

    public void removeDup();

    public int size();

    public void trimToSize();

    public IntBag union(IntBag b);

    public IntBag clone();
}