/*
 * IntArrayBagDemo.java
 *
 * Created on January 27, 2004, 10:45 AM
 * Modified on July 14, 2016
 */

/**
 *
 * @author Lunjin Lu
 *         This class demonostrates the use of the
 *         IntArrayBag class and the IntBag class
 *
 */
public abstract class IntArrayBagDemo {

    /** Creates a new instance of IntArrayBagDemo */
    public IntArrayBagDemo() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IntBag b = new IntArrayBag(10);
        IntBag c;
        b.add(5);
        b.add(3);
        b.add(7);
        System.out.println(b);
        b.addAll(b);
        System.out.println(b);
        c = b.union(b);
        System.out.println(c);
        System.out.println(b);
        b.remove(5);
        b.remove(7);
        System.out.println(b);
        /* System.out.println(((IntArrayBag) b).clone()); */

        System.out.println(b.clone());
    }
}
