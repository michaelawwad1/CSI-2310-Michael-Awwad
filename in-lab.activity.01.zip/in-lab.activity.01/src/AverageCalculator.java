import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AverageCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the filename: ");
        String filename = input.nextLine();

        try {
            File file = new File(filename);
            Scanner fileScanner = new Scanner(file);

            int sum = 0;
            int count = 0;

            while (fileScanner.hasNextInt()) {
                sum += fileScanner.nextInt();
                count++;
            }

            fileScanner.close();

            if (count > 0) {
                double average = (double) sum / count;
                System.out.println("Average: " + average);
            } else {
                System.out.println("No integers found in the file.");
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        }

        input.close();
    }
}