public class Quadratic {
    private double a;
    private double b;
    private double c;

    // Constructor sets all coefficients to zero
    public Quadratic() {
        this.a = 0;
        this.b = 0;
        this.c = 0;
    }

    // Method to change the coefficients
    public void setCoefficients(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    // Accessor methods to retrieve coefficients
    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

    // Method to evaluate the quadratic expression at a particular value of x
    public double evaluate(double x) {
        return a * x * x + b * x + c;
    }

    // Static method to sum two quadratic expressions
    public static Quadratic sum(Quadratic q1, Quadratic q2) {
        Quadratic result = new Quadratic();
        result.setCoefficients(q1.a + q2.a, q1.b + q2.b, q1.c + q2.c);
        return result;
    }

    // Static method to scale a quadratic expression by a number
    public static Quadratic scale(double r, Quadratic q) {
        Quadratic result = new Quadratic();
        result.setCoefficients(r * q.a, r * q.b, r * q.c);
        return result;
    }

    // Method to check equality with another object
    public boolean equals(Object obj) {
        if (!(obj instanceof Quadratic)) {
            return false;
        }
        Quadratic q = (Quadratic) obj;
        return this.a == q.a && this.b == q.b && this.c == q.c;
    }

    // Method to create a copy of this Quadratic object
    public Quadratic clone() {
        Quadratic copy = new Quadratic();
        copy.setCoefficients(this.a, this.b, this.c);
        return copy;
    }

    // Method to return a string representation
    public String toString() {
        return a + "x^2 + " + b + "x + " + c;
    }
}