public class QuadraticDemo {
    public static void main(String[] args) {
        System.out.println("=== Quadratic Expression Demo ===\n");

        // Create quadratic objects
        Quadratic q1 = new Quadratic();
        Quadratic q2 = new Quadratic();

        // Demonstrate setCoefficients method
        System.out.println("1. Setting coefficients:");
        q1.setCoefficients(2, 3, -5);
        q2.setCoefficients(1, -2, 4);
        System.out.println("   q1 = " + q1);
        System.out.println("   q2 = " + q2);

        // Demonstrate accessor methods
        System.out.println("\n2. Accessing coefficients of q1:");
        System.out.println("   a = " + q1.getA());
        System.out.println("   b = " + q1.getB());
        System.out.println("   c = " + q1.getC());

        // Demonstrate evaluate method
        System.out.println("\n3. Evaluating expressions:");
        double x = 2.0;
        System.out.println("   q1 at x = " + x + ": " + q1.evaluate(x));
        System.out.println("   q2 at x = " + x + ": " + q2.evaluate(x));

        // Demonstrate sum method
        System.out.println("\n4. Sum of two quadratics:");
        Quadratic sum = Quadratic.sum(q1, q2);
        System.out.println("   q1 + q2 = " + sum);

        // Demonstrate scale method
        System.out.println("\n5. Scaling a quadratic:");
        double scaleFactor = 3.0;
        Quadratic scaled = Quadratic.scale(scaleFactor, q1);
        System.out.println("   " + scaleFactor + " * q1 = " + scaled);

        // Demonstrate equals method
        System.out.println("\n6. Testing equality:");
        Quadratic q3 = new Quadratic();
        q3.setCoefficients(2, 3, -5);
        System.out.println("   q1 equals q2? " + q1.equals(q2));
        System.out.println("   q1 equals q3? " + q1.equals(q3));

        // Demonstrate clone method
        System.out.println("\n7. Cloning a quadratic:");
        Quadratic q1Clone = q1.clone();
        System.out.println("   Original q1: " + q1);
        System.out.println("   Cloned q1: " + q1Clone);
        System.out.println("   Are they equal? " + q1.equals(q1Clone));
        System.out.println("   Are they the same object? " + (q1 == q1Clone));

        // Demonstrate toString method (already used above)
        System.out.println("\n8. String representation:");
        Quadratic q4 = new Quadratic();
        q4.setCoefficients(1, 0, -9);
        System.out.println("   q4 = " + q4);
        Quadratic q5 = new Quadratic();
        q5.setCoefficients(0, 0, 0);
        System.out.println("   q5 (all zeros) = " + q5);

        System.out.println("\n=== Demo Complete ===");
    }
}