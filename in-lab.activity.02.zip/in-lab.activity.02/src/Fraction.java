public class Fraction implements Cloneable {
    /** den>0 and num and den has no common divisor other than 1. */
    private int num;
    private int den;

    private int gcd(int a, int b) {
        if (b == 0)
            return a;
        else
            return gcd(b, a % b);
    }

    @Override
    public boolean equals(Object f) {

        if (this == f)
            return true;

        if (f == null || !(f instanceof Fraction))
            return false;
        Fraction other = (Fraction) f;
        return this.num == other.num && this.den == other.den;
    }

    @Override
    public String toString() {
        if (den == 1) {
            return String.valueOf(num);
        }
        return num + "/" + den;
    }
}